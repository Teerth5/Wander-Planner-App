package com.example.vacationplanner;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class HotelActivity extends AppCompatActivity {

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_hotel);

        WebView hotelsWebView = findViewById(R.id.hotelsWebView);
        hotelsWebView.setWebViewClient(new WebViewClient()); // Open links in the WebView instead of browser
        WebSettings webSettings = hotelsWebView.getSettings();
        webSettings.setJavaScriptEnabled(true); // Enable JavaScript

        // Load the Goibibo website
        hotelsWebView.loadUrl("https://www.goibibo.com/hotels/");

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.hotel), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}
