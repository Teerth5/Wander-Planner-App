package com.example.vacationplanner;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class UdaipurActivity extends AppCompatActivity {

    ImageView backbutton;
    Button flight_btn,hotel_btn,itenary_btn;
    ImageView like_btn;


    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.udaipur);

        backbutton = (ImageView) findViewById(R.id.imageView4);
        flight_btn = (Button) findViewById(R.id.button);
        hotel_btn = (Button) findViewById(R.id.button2);
        itenary_btn = (Button) findViewById(R.id.button3);
        like_btn = (ImageView) findViewById(R.id.imageView6);

        flight_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(UdaipurActivity.this, FlightActivity.class));
            }
        });

        hotel_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(UdaipurActivity.this, HotelActivity.class));
            }
            });

        itenary_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(UdaipurActivity.this, UdaipurItenary.class));
            }
        });

        like_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getApplicationContext(),"Added to favourites",Toast.LENGTH_SHORT).show();
            }
        });


        backbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(UdaipurActivity.this, MainActivity.class));
            }
        });


        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.udaipur), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}
