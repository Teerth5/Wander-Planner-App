package com.example.vacationplanner;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class FlightActivity extends AppCompatActivity {

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_flight);

        WebView flightsWebView = findViewById(R.id.flightsWebView);
        flightsWebView.setWebViewClient(new WebViewClient()); // Open links in the WebView instead of browser
        WebSettings webSettings = flightsWebView.getSettings();
        webSettings.setJavaScriptEnabled(true); // Enable JavaScript

        // Load the Skyscanner website
        flightsWebView.loadUrl("https://www.skyscanner.net/");



        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.flight), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }


}