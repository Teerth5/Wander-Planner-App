package com.example.vacationplanner.adapter;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.vacationplanner.JaipurActivity;
import com.example.vacationplanner.MunnarActivity;
import com.example.vacationplanner.PangongActivity;
import com.example.vacationplanner.R;
import com.example.vacationplanner.RishikeshActivity;
import com.example.vacationplanner.ShilongActivity;
import com.example.vacationplanner.ShimlaActivity;
import com.example.vacationplanner.UdaipurActivity;
import com.example.vacationplanner.model.RecentsData;

import java.util.List;

public class RecentsAdapter extends RecyclerView.Adapter<RecentsAdapter.RecentsViewHolder>{

    Context context;
    List<RecentsData> recentsDataList;

    public RecentsAdapter(List<RecentsData> recentsDataList, Context context) {
        this.recentsDataList = recentsDataList;
        this.context = context;
    }

    @NonNull
    @Override
    public RecentsViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.recents_row_item,parent,false);

        // Recylar view item layout file
        return new RecentsViewHolder(view);

    }

    @Override
    public void onBindViewHolder(@NonNull RecentsViewHolder holder, @SuppressLint("RecyclerView") int position) {
        holder.countryname.setText(recentsDataList.get(position).getCountryName());
        holder.placeName.setText(recentsDataList.get(position).getPlaceName());
        holder.price.setText(recentsDataList.get(position).getPrice());
        holder.placeImage.setImageResource(recentsDataList.get(position).getImageUrl());

        // Set a click listener with conditionals to handle different actions based on place name
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent =  null;
                String placeName = recentsDataList.get(position).getPlaceName();

                // Use placeName to determine which activity to open
                switch (placeName) {
                    case "Udaipur":
                        intent = new Intent(context, UdaipurActivity.class);
                        break;
                    case "Shimla":
                        intent = new Intent(context, ShimlaActivity.class);
                        break;
                    case "Shilong":
                        intent = new Intent(context, ShilongActivity.class);
                        break;
                    case "Rishikesh":
                        intent = new Intent(context, RishikeshActivity.class);
                        break;
                    case "Pangong Tso Lake":
                        intent = new Intent(context, PangongActivity.class);
                        break;
                    case "Munnar":
                        intent = new Intent(context, MunnarActivity.class);
                        break;
                    case "Jaipur":
                        intent = new Intent(context, JaipurActivity.class);
                        break;
                    default:
                        throw new IllegalStateException("Unexpected value: " + placeName);
                }

                // Check if intent is not null before starting the activity
                if (intent != null) {
                    context.startActivity(intent);
                }
            }
        });



    }


    @Override
    public int getItemCount() {
        return recentsDataList.size();
    }


    public static final class RecentsViewHolder extends RecyclerView.ViewHolder{
        ImageView placeImage;
        TextView placeName,countryname,price;


        public RecentsViewHolder(@NonNull View itemView) {
            super(itemView);

            placeImage = itemView.findViewById(R.id.place_image);
            placeName =  itemView.findViewById(R.id.place_name);
            countryname=itemView.findViewById(R.id.country_name);
            price = itemView.findViewById(R.id.price);

        }
    }


}
