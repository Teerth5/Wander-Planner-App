package com.example.vacationplanner;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.vacationplanner.adapter.RecentsAdapter;
import com.example.vacationplanner.adapter.TopPlacesAdapter;
import com.example.vacationplanner.model.RecentsData;
import com.example.vacationplanner.model.TopPlacessData;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    RecyclerView recentRecycler,topPlacesRecycler;
    RecentsAdapter recentsAdapter;
    TopPlacesAdapter topPlacesAdapter;
    ImageView home_button,profile_button,flight_button,hotel_button;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        home_button = (ImageView) findViewById(R.id.home);
        profile_button = (ImageView) findViewById(R.id.profile);
        flight_button = (ImageView) findViewById(R.id.flight);
        hotel_button = (ImageView) findViewById(R.id.hotel);

        profile_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this,ProfileActivity.class));

            }
        });

        flight_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this, FlightActivity.class));
            }
        });

        hotel_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(MainActivity.this, HotelActivity.class));
            }
        });


        List<RecentsData> recentsDataList = new ArrayList<>();
        recentsDataList.add(new RecentsData("Udaipur","India","from $200",R.drawable.udaipur));
        recentsDataList.add(new RecentsData("Shimla","India","from $300",R.drawable.shimla));
        recentsDataList.add(new RecentsData("Shilong ","India","from $220",R.drawable.shilong));
        recentsDataList.add(new RecentsData("Rishikesh","India","from $350",R.drawable.rishikesh));
        recentsDataList.add(new RecentsData("Pangong Tso Lake","India","from $400",R.drawable.pangong_tso_lake));
        recentsDataList.add(new RecentsData("Munnar","India","from $145", R.drawable.munnar));
        recentsDataList.add(new RecentsData("Jaipur ","India","from 250",R.drawable.jaiput));

        setRecentRecycler(recentsDataList);
        // recentsDataList.add(new RecentsData("Goa","India","from $275",R.drawable.gangtok));
        // recentsDataList.add(new RecentsData("Gangtok","India","from $145",R.drawable.munnar));
        // recentsDataList.add(new RecentsData("Amritsar","India","from $145",R.drawable.amritsar));
        // recentsDataList.add(new RecentsData("Andaman and Nicobar Islands","India","from $320",R.drawable.andaman_nicobar));
        // recentsDataList.add(new RecentsData("Varanasi","India","from $100",R.drawable.varanasi));
        // recentsDataList.add(new RecentsData("Lakshwadeep","India","from $330",R.drawable.lakshwadeep));


        List<TopPlacessData> topPlacessDataList = new ArrayList<>();
        topPlacessDataList.add(new TopPlacessData("Kashmir Hills","India","$200-$400",R.drawable.kashmir_hills));
        topPlacessDataList.add(new TopPlacessData("Goa","India","$200-$275",R.drawable.goa));
        topPlacessDataList.add(new TopPlacessData("Amritsar","India","$150-$200",R.drawable.amritsar));
        topPlacessDataList.add(new TopPlacessData("Gangtok","India","$250-$200",R.drawable.gangtok));
        topPlacessDataList.add(new TopPlacessData("Andaman and Nicobar Islands","India","$220-$280",R.drawable.andaman_nicobar));
        topPlacessDataList.add(new TopPlacessData("Varanasi","India","$150-$200",R.drawable.varanasi));
        topPlacessDataList.add(new TopPlacessData("Lakshwadeep","India","$300-$350",R.drawable.lakshwadeep));

        setTopPlacesRecycler(topPlacessDataList);




        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    private void setRecentRecycler(List<RecentsData> recentsDataList) {

        recentRecycler = findViewById(R.id.recent_recycler);

        RecyclerView.LayoutManager layoutManager =  new LinearLayoutManager(this,RecyclerView.HORIZONTAL, false);
        recentRecycler.setLayoutManager(layoutManager);
        recentsAdapter= new RecentsAdapter(recentsDataList, this);
        recentRecycler.setAdapter(recentsAdapter);
    }

    private void setTopPlacesRecycler(List<TopPlacessData> topPlacessDataList) {

        topPlacesRecycler = findViewById(R.id.top_places_recycler);

        RecyclerView.LayoutManager layoutManager =  new LinearLayoutManager(this,RecyclerView.VERTICAL, false);
        topPlacesRecycler.setLayoutManager(layoutManager);
        topPlacesAdapter= new TopPlacesAdapter(topPlacessDataList, this);
        topPlacesRecycler.setAdapter(topPlacesAdapter);

    }
}