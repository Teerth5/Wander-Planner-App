package com.example.vacationplanner.adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.vacationplanner.AmritsarActivity;
import com.example.vacationplanner.AndamanNicobarActivity;
import com.example.vacationplanner.GangtokActivity;
import com.example.vacationplanner.GoaActivity;
import com.example.vacationplanner.JaipurActivity;
import com.example.vacationplanner.KashmirHillsActivity;
import com.example.vacationplanner.LakshwadeepActivity;
import com.example.vacationplanner.MunnarActivity;
import com.example.vacationplanner.PangongActivity;
import com.example.vacationplanner.R;
import com.example.vacationplanner.RishikeshActivity;
import com.example.vacationplanner.ShilongActivity;
import com.example.vacationplanner.ShimlaActivity;
import com.example.vacationplanner.UdaipurActivity;
import com.example.vacationplanner.VaranasiActivity;
import com.example.vacationplanner.model.TopPlacessData;

import java.util.ArrayList;
import java.util.List;

public class TopPlacesAdapter extends RecyclerView.Adapter<TopPlacesAdapter.TopPlacesViewHolder> {

    private Context context;
    private List<TopPlacessData> topPlacessDataList;

    public TopPlacesAdapter(List<TopPlacessData> recentsDataList, Context context) {
        // Initialize the list with an empty list if the provided list is null
        this.topPlacessDataList = (recentsDataList != null) ? recentsDataList : new ArrayList<>();
        this.context = context;
    }

    @NonNull
    @Override
    public TopPlacesViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.top_places_row_item, parent, false);
        return new TopPlacesViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull TopPlacesViewHolder holder, @SuppressLint("RecyclerView") int position) {
        // Check if the list has items before attempting to access it
        if (topPlacessDataList != null && !topPlacessDataList.isEmpty()) {
            TopPlacessData place = topPlacessDataList.get(position);
            holder.countryname.setText(place.getCountryName());
            holder.placeName.setText(place.getPlaceName());
            holder.price.setText(place.getPrice());
            holder.placeImage.setImageResource(place.getImageUrl());

            // Set a click listener with conditionals to handle different actions based on place name
            holder.itemView.setOnClickListener(view -> {
                Intent intent = null;
                switch (place.getPlaceName()) {
                    case "Kashmir Hills":
                        intent = new Intent(context, KashmirHillsActivity.class);
                        break;
                    case "Goa":
                        intent = new Intent(context, GoaActivity.class);
                        break;
                    case "Amritsar":
                        intent = new Intent(context, AmritsarActivity.class);
                        break;
                    case "Gangtok":
                        intent = new Intent(context, GangtokActivity.class);
                        break;
                    case "Andaman and Nicobar Islands":
                        intent = new Intent(context, AndamanNicobarActivity.class);
                        break;
                    case "Varanasi":
                        intent = new Intent(context, VaranasiActivity.class);
                        break;
                    case "Lakshwadeep":
                        intent = new Intent(context, LakshwadeepActivity.class);
                        break;
                    default:
                        // Show an error message if no activity is found
                        Toast.makeText(context, "Error: no page found for this place", Toast.LENGTH_SHORT).show();
                        return;
                }
                if (intent != null) {
                    context.startActivity(intent);
                }
            });
        }
    }

    @Override
    public int getItemCount() {
        // Return 0 if the list is null or empty
        return (topPlacessDataList != null) ? topPlacessDataList.size() : 0;
    }

    public static final class TopPlacesViewHolder extends RecyclerView.ViewHolder {
        ImageView placeImage;
        TextView placeName, countryname, price;

        public TopPlacesViewHolder(@NonNull View itemView) {
            super(itemView);
            placeImage = itemView.findViewById(R.id.place_image);
            placeName = itemView.findViewById(R.id.place_name);
            countryname = itemView.findViewById(R.id.country_name);
            price = itemView.findViewById(R.id.price);
        }
    }
}
